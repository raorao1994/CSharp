## [Imgur](https://github.com/ServiceStackApps/Imgur)

> Imgur-like App to resize uploaded images in all iOS Resolutions in <30 lines of JavaScript + 1 ServiceStack ImageService

[![](https://raw.githubusercontent.com/ServiceStack/Assets/master/img/livedemos/imgur.png)](http://imgur.servicestack.net)

#### Features

 - [1 default.html page](https://github.com/ServiceStackApps/Imgur/blob/master/src/Imgur/default.html)
 - [1 ServicStack back-end .cs file](https://github.com/ServiceStackApps/Imgur/blob/master/src/Imgur/Global.asax.cs)

Try it out live at: [imgur.servicestack.net](http://imgur.servicestack.net)

Follow [@ServiceStack](http://twitter.com) or [+ServiceStack](https://plus.google.com/u/0/communities/112445368900682590445) for updates.
