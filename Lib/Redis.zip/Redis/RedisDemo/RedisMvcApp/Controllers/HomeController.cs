﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RedisMvcApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        //1.怎样在MVC中捕获异常信息.

        public ActionResult Index()
        {
            int a = 2;
            int b = 0;
            int c = a / b;
            return View();
        }

    }
}
