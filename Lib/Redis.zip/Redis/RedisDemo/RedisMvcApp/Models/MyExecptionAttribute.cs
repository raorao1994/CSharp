﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ServiceStack.Redis;
namespace RedisMvcApp.Models
{
    public class MyExecptionAttribute : HandleErrorAttribute
    {
        //public static Queue<Exception> ExceptionQueue = new Queue<Exception>();//创建队列.
        public static IRedisClientsManager clientManager = new PooledRedisClientManager(new string[]{"127.0.0.1:6379"});
        public static IRedisClient redisClent = clientManager.GetClient();
        public override void OnException(ExceptionContext filterContext)
        {
          //将异常信息入队.
            //ExceptionQueue.Enqueue(filterContext.Exception);//将异常信息入队.
            redisClent.EnqueueItemOnList("errorException", filterContext.Exception.ToString());//将异常信息存储到Redis队列中了。
            filterContext.HttpContext.Response.Redirect("/error.html");
            base.OnException(filterContext);
        }
    }
}