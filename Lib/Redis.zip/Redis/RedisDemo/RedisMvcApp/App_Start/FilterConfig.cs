﻿using RedisMvcApp.Models;
using System.Web;
using System.Web.Mvc;

namespace RedisMvcApp
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new HandleErrorAttribute());
            filters.Add(new MyExecptionAttribute());
        }
    }
}